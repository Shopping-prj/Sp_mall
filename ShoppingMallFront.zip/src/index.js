import ReactDOM from 'react-dom/client';
import "bootstrap/dist/css/bootstrap.min.css"
import "react-datetime/css/react-datetime.css";
import App from './App';
import { BrowserRouter } from 'react-router-dom';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </>
);
