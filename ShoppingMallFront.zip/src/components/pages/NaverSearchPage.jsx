import React, { useState } from "react";

const NaverSearchPage = () => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!query.trim()) return;

    try {
      // 실제 API 호출 예시 (백엔드 프록시 권장)
      const response = await fetch(
        `/api/naver-shop?query=${encodeURIComponent(query)}`
      );
      const data = await response.json();

      setResults(data.items || []); // 네이버 API는 items 배열 반환
    } catch (error) {
      console.error("API 호출 오류:", error);
    }
  };

  return (
    <div className="search_shop" style={{ margin: "10px" }}>
      <form onSubmit={handleSubmit}>
        <fieldset className="srch" style={{ margin: "0px 10px" }}>
          <legend style={{ display: "none" }}>검색영역</legend>
          <input
            type="text"
            name="query"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="검색어"
            className="keyword"
            style={{ marginLeft: "1px", padding: "2px 3px 5px" }}
          />
          <input type="submit" value="검색" />
        </fieldset>
      </form>

      <table
        className="tbl_type"
        style={{
          width: "100%",
          borderBottom: "2px solid #dcdcdc",
          fontFamily: "Tahoma",
          fontSize: "11px",
          textAlign: "center",
          marginTop: "20px",
        }}
      >
        <caption style={{ display: "none" }}>쇼핑검색 API 결과</caption>
        <colgroup>
          <col width="10%" />
          <col width="20%" />
          <col width="15%" />
          <col width="15%" />
          <col width="15%" />
        </colgroup>
        <thead>
          <tr>
            <th>상품이미지</th>
            <th>상품명</th>
            <th>최고가</th>
            <th>최저가</th>
            <th>판매몰</th>
          </tr>
        </thead>
        <tbody>
          {results.map((data, index) => (
            <tr key={index}>
              <td>
                <img
                  src={data.image}
                  alt={data.title}
                  width="50"
                  height="70"
                />
              </td>
              <td>
                <a href={data.link} target="_blank" rel="noopener noreferrer">
                  {data.title}
                </a>
              </td>
              <td>{data.hprice || "-"}</td>
              <td>{data.lprice || "-"}</td>
              <td>{data.mallName}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default NaverSearchPage;
