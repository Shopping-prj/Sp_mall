// src/auth/LoginPage.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Container, Form, Button, Row, Col, Card, InputGroup } from "react-bootstrap";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { loginMember } from "service/memberDB";
import { useCart } from "context/CartContext";
import { useAuth } from "context/AuthContext";
import ShopNavbar from "components/include/ShopNavbar";
import { getCartByEmail } from "service/cartDB";

const LoginPage = () => {
  const { setCartItems } = useCart();
  const { login } = useAuth();
  const navigate = useNavigate();

  const [User, setUser] = useState({
    m_email: "",
    m_password: "",
  });

  const changeUser = (e) => {
    const id = e.currentTarget.id;
    const value = e.target.value;
    setUser({ ...User, [id]: value });
  };

  const [passwordType, setPasswordType] = useState({
    type: "password",
    visible: false,
  });

  const passwordView = () => {
    setPasswordType((prev) => ({
      type: prev.visible ? "password" : "text",
      visible: !prev.visible,
    }));
  };

  const loginE = async () => {
  try {
    const userData = await loginMember(User.m_email, User.m_password);
    login(userData);
    const cart = await getCartByEmail(userData.m_email);  // ✅ 직접 호출
    setCartItems(cart.items || []);
    navigate("/shop");
  } catch (err) {
    console.error("로그인 실패:", err);
    alert(err.response?.data?.message || "로그인 실패");
  }
};

  const loginG = () => {
    const googleUrl = "https://accounts.google.com/o/oauth2/auth";
    const googleClientId = "858945058074-7droigq2d1o18bh69su5q5frd9qff4m2.apps.googleusercontent.com";
    const googleRedirectUrl = "http://localhost:3000/oauth/google/redirect";
    const googleScope = "openid profile email";

    const auth_uri = `${googleUrl}?client_id=${googleClientId}&redirect_uri=${googleRedirectUrl}&response_type=code&scope=${googleScope}`;
    window.location.href = auth_uri;
  };

  const loginK = () => {
    const kakaoUrl = "https://kauth.kakao.com/oauth/authorize";
    const kakaoClientId = "ac8481e5c39e26462dda5a549b1aaa39";
    const kakaoRedirectUrl = "http://localhost:3000/oauth/kakao/redirect";

    const auth_uri = `${kakaoUrl}?client_id=${kakaoClientId}&redirect_uri=${kakaoRedirectUrl}&response_type=code`;
    window.location.href = auth_uri;
  };

  return (
    <>
      <ShopNavbar />
      <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
        <Row className="w-100 justify-content-center">
          <Col md={6} lg={4}>
            <Card className="shadow-sm" style={{ borderRadius: "10px", padding: "30px 20px" }}>
              <Card.Body>
                <h3 className="text-center mb-4">로그인</h3>
                <Form>
                  <Form.Group className="mb-3" controlId="m_email">
                    <Form.Label>이메일</Form.Label>
                    <Form.Control
                      type="email"
                      placeholder="이메일을 입력해주세요"
                      value={User.m_email}
                      onChange={changeUser}
                      style={{ height: "48px" }}
                    />
                  </Form.Group>

                  <Form.Group className="mb-3" controlId="m_password">
                    <Form.Label>비밀번호</Form.Label>
                    <InputGroup>
                      <Form.Control
                        type={passwordType.type}
                        placeholder="비밀번호를 입력해주세요"
                        value={User.m_password}
                        onChange={changeUser}
                      />
                      <InputGroup.Text
                        style={{ cursor: "pointer", backgroundColor: "white" }}
                        onClick={passwordView}
                      >
                        {passwordType.visible ? <FaEyeSlash /> : <FaEye />}
                      </InputGroup.Text>
                    </InputGroup>
                  </Form.Group>

                  <Button className="w-100 mb-3" variant="primary" type="button" onClick={loginE} style={{ height: "48px", fontWeight: "500" }}>
                    로그인
                  </Button>

                  <div className="text-center my-3 text-muted">또는</div>

                  <Button
                    variant="light"
                    className="w-100 mb-2 p-0 border"
                    onClick={loginG}
                    style={{ height: "48px", overflow: "hidden", borderRadius: "12px" }}
                  >
                    <img src="../srcimg/google-signin-assets/web/web_neutral_sq_SI@2x.png" alt="구글 로그인"
                         style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  </Button>

                  <Button
                    variant="light"
                    className="w-100 mb-2 p-0 border"
                    onClick={loginK}
                    style={{ height: "48px", overflow: "hidden", borderRadius: "12px" }}
                  >
                    <img src="../srcimg/kakao/kakao_login_large_narrow.png" alt="카카오 로그인"
                         style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  </Button>

                  <div className="mt-4 text-center" style={{ fontSize: "0.9rem", lineHeight: "1.8" }}>
                    <p>신규 사용자이신가요? <Link to="/api/members/join">계정 만들기</Link></p>
                    <p>이메일을 잊으셨나요? <Link to="/login/findEmail">이메일 찾기</Link></p>
                    <p>비밀번호를 잊으셨나요? <Link to="/login/resetPwd">비밀번호 변경</Link></p>
                  </div>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default LoginPage;
