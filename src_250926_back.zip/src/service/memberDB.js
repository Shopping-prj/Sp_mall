import axios from "axios";

// 로컬 로그인 요청
export const loginMember = async (m_email, m_password, m_amount) => {
  const res = await axios({
    method: "post",
    url: `${process.env.REACT_APP_SPRING_IP}/api/members/login`,
    data: {
      m_email,   // Spring Security 기본 파라미터명
      m_password,
      m_amount,
    },
    headers: { "Content-Type": "application/json" },
  });

  return res.data;
};
