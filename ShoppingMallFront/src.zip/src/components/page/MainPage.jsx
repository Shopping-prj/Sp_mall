import React from 'react'
import Header from '../include/Header'
import Footer from '../include/Footer'

const MainPage = () => {
  return (
    <>
      관리자 메인 페이지
    </>
  )
}

export default MainPage