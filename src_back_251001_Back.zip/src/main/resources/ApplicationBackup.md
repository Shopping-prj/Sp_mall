```yml
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://project-mall-db.cpocwiywq77l.ap-southeast-2.rds.amazonaws.com:3306/test_mall?serverTimezone=Asia/Seoul&characterEncoding=UTF-8
    username: admin
    password: abcd1234
    hikari:
      maximum-pool-size: 10      # 커넥션 풀 크기
      minimum-idle: 5            # 최소 유휴 커넥션
      idle-timeout: 30000        # idle 커넥션 유지 시간(ms)
      connection-timeout: 30000  # 커넥션 획득 최대 대기 시간(ms)
      max-lifetime: 1800000      # 커넥션 최대 수명(ms)

mybatis:
  mapper-locations: classpath:/mapper/**/*.xml
  type-aliases-package: com.example.demo.model
  configuration:
    map-underscore-to-camel-case: true  # DB 컬럼명(snake_case) → Java 필드(camelCase) 자동 매핑

```